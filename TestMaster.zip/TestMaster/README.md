# Test Master — journey to automation

Test Master is a self-contained Chrome/Edge Manifest V3 extension starter. It turns a real browser journey into a locally stored action timeline, screenshot evidence, AI-assisted manual test drafts, and a downloadable Playwright/TypeScript starter project.

The source is deliberately dependency-free: HTML, CSS, ES modules' language features, and browser APIs only. Load the folder as an unpacked extension from `chrome://extensions` or `edge://extensions` with Developer mode enabled. Click the extension action to open its side panel. Use a user-owned Groq API key in Settings to enable generation.

## Product strategy

### Vision

Make the browser session the traceable source of truth for quality work: observe an actual journey once, then carry its evidence and context through reviewable manual and automated test drafts.

### Personas and value

| Persona | Need | Test Master value |
| --- | --- | --- |
| QA analyst | Capture steps and evidence without re-documenting them | Timeline, timestamps, redaction, screenshots and export from the same session |
| Senior QA / test designer | Design broad, explainable cases grounded in observed behavior | Configurable coverage/techniques, source-step references, reviewable expected results |
| SDET | Convert selected cases into a maintainable automation starting point | Playwright/TypeScript project scaffold with page-object locators and explicit TODOs |
| QA lead | Improve consistency and reviewability across a team | One structured session record and a visible evidence-to-test relationship |

Business value is reduced duplicate documentation and faster hand-off from exploratory work to test design. Differentiators are browser-native capture, local-first evidence, explicit traceability, opt-in AI, and generated automation that exposes unverified assumptions rather than disguising them.

This starter is a single-user extension, not a hosted team platform: it has no account system, synchronization, signed audit trail, central policy, or administrator-managed secrets.

## UX and design system

### Information architecture and flow

The persistent side panel has five work areas: **Overview**, **Journey recorder**, **Test cases**, **Automation**, and **Evidence**; **Settings** holds AI and local-data controls. The primary loop is:

1. Open a supported HTTP(S) page and start a journey.
2. Interact with the page; review, pause/resume, capture a viewport, add session notes, and stop.
3. Configure the AI inputs; request and review behavior-grounded test-case drafts.
4. Select individual/all reviewed cases; download the TypeScript project.
5. Export the recorded execution record as DOCX, PDF, XLSX, JSON, or CSV.

### Visual language

| Token | Value | Use |
| --- | --- | --- |
| Canvas | `#F5F6FA` | Quiet workspace background |
| Surface | `#FFFFFF` | Panels, tables, controls |
| Ink | `#202239` | Primary text |
| Muted | `#898BA0` | Supporting labels |
| Primary | `#7259E8` | Main actions, active navigation |
| Blue / mint / amber | `#6386ED` / `#38AD89` / `#D99A3B` | Status and data accents |
| Dark canvas / surface | `#191824` / `#242330` | User-toggleable dark theme |

Typography uses system UI fonts for zero-network, offline rendering. Icons are lightweight text glyphs to avoid remote assets and extra packages; production polish should replace these with a consistent local, accessible icon set. Cards use 12–16 px radii, low-contrast borders, restrained shadows, and purple-tinted glass-like surfaces. Motion is limited to short state transitions and nonessential reveal effects. The panel collapses its sidebar at narrow widths and stacks content below 690 px.

Reusable UI patterns include primary/subtle/quiet buttons, status chips, session metric cards, filter chips, searchable tables, timeline step markers, evidence rows, export-format buttons, privacy notices, and transient ARIA-live toasts. Dark mode is stored locally. Respect `prefers-reduced-motion` and expand keyboard/focus/contrast checks before production release.

## Extension architecture

```mermaid
flowchart LR
  User[Tester] --> Panel[Side panel: app.html / app.js]
  Panel --> Worker[MV3 service worker: background.js]
  Worker --> Content[Per-tab recorder: content.js]
  Content --> Page[Active HTTP(S) page DOM]
  Content -->|structured actions| Worker
  Worker --> Local[chrome.storage.local]
  Panel -->|evidence exports| Export[exports.js: OOXML / PDF]
  Export --> Downloads[chrome.downloads]
  Panel -->|explicit generation request| Worker
  Worker -->|HTTPS request, user key| Groq[Groq API]
  Groq --> Worker
  Worker -->|validated JSON draft| Panel
```

### Component responsibilities and data flow

* `manifest.json`: MV3 metadata, side panel, service worker, options page, and least-privilege permissions.
* `background.js`: tab selection, content-script injection, recorder lifecycle, serialized action writes, visible-tab capture, local persistence, Groq fetch, and downloads.
* `content.js`: event delegation on the active page, labels/attributes/locator candidates, value redaction, and URL-aware action messages. It does not collect page HTML wholesale.
* `app.html` / `app.css` / `app.js`: side-panel workspace, navigation, interaction state, test-case review, settings, and automation assembly.
* `exports.js`: dependency-free ZIP/OOXML assembly for DOCX/XLSX, small text-first PDF generation, JSON/CSV, and a print-ready HTML report.
* `options.html` / `options.css` / `options.js`: standalone extension options for the AI key/model.

The worker is the storage/API boundary. The panel asks it for session state; the content script sends each captured action to the worker; the worker appends a numbered/timestamped record and notifies the panel through `chrome.storage.onChanged`. Screenshot capture uses the browser's visible viewport API and associates the image with the latest step. AI requests contain recorded action metadata and a sanitized snapshot of visible controls/headings on the current page; screenshots are sent only when the tester explicitly enables image input. AI output is parsed and filtered for valid shape and references to existing step numbers before storage.

### Suggested production project structure

```text
test-master/
├── manifest.json
├── src/
│   ├── background/service-worker.js
│   ├── content/recorder.js
│   ├── panel/{index.html,app.ts,styles.css}
│   ├── options/{index.html,options.ts,styles.css}
│   ├── core/{session,locators,redaction,schema}.ts
│   ├── ai/{groq-client,prompts,validation}.ts
│   ├── evidence/{capture,docx,pdf,xlsx}.ts
│   └── automation/{playwright,templates}.ts
├── assets/{TestMaster.jpg,icon16.png,icon32.png,icon48.png,icon128.png}
├── tests/{unit,integration,e2e}/
├── docs/
├── package.json
└── tsconfig.json
```

The delivered starter keeps those modules at the root and uses vanilla JS as requested. A production build should add TypeScript, unit and extension integration tests, local static assets, schema versioning/migrations, and a reproducible packaging pipeline.

## Manifest V3, permissions, and lifecycle

The manifest uses `activeTab`, `scripting`, `storage`, `downloads`, and `sidePanel`; the sole declared host origin is Groq's HTTPS API. Clicking the extension action explicitly opens the side panel from the action's user-gesture handler, so Chrome can grant `activeTab` for the selected page without a broad `tabs` permission. The worker reads page URL/title from the accessible page rather than depending on `tabs.query()` exposing `tab.url`. A cross-origin full-page navigation can revoke temporary access; if injection fails, this version pauses and surfaces a permission/interruption message rather than silently pretending to capture. Validate this lifecycle on each supported Chrome/Edge release.

The service worker may be suspended between events. Session and settings live in `chrome.storage.local`; worker globals are caches only. The action queue prevents concurrent record messages from assigning duplicate step numbers. Each journey is bounded at 2,000 actions and 12 reduced-size screenshots. The initial prototype stores one current journey rather than maintaining a searchable archive; export before resetting it.

## Recording engine

### Event capture

Delegated listeners capture click, double/right-click, keyboard navigation keys, debounced text input, dropdown, checkbox, radio, date, file-upload count, form-submit, drag/drop, history changes, and full-page navigation where host access permits. Mouse-hover events are intentionally excluded. Each action carries a step number, UTC timestamp, page URL, human-readable label/text, selected attributes, preferred/alternate locator candidates, and screenshot IDs. Text entry is debounced to avoid keystroke-level noise.

The prototype redacts passwords and values from fields whose type/name/id/autocomplete/placeholder looks like a password, token, secret, card, CVV, or one-time code. It intentionally records other form values to support test-data review; production should add configurable allowlists, PII detection, consent, redaction previews, and a per-field "never record" policy. File names and file contents are not collected.

### Locator strategy and session schema

Prefer stable IDs, `data-testid`, accessible labels/names, role/name, and stable attributes; keep alternates and visible text as fallbacks. A candidate is not guaranteed unique or stable. Re-check locator uniqueness and visibility before code generation; never claim self-healing. A versioned production schema should include:

```json
{
  "id": "session-uuid",
  "schemaVersion": 1,
  "status": "recording",
  "tester": "QA Analyst",
  "applicationUrl": "https://example.test/",
  "startedAt": "UTC timestamp",
  "steps": [{
    "stepNumber": 1,
    "type": "Click",
    "elementLabel": "Continue",
    "elementText": "Continue",
    "attributes": {"tagName": "BUTTON", "type": "submit"},
    "preferredLocator": "button text locator",
    "alternateLocators": [],
    "url": "https://example.test/",
    "timestamp": "UTC timestamp",
    "screenshotIds": []
  }],
  "screenshots": [],
  "notes": ""
}
```

Pause, resume, stop, and reset are explicit state transitions. Treat reset as destructive and confirm it; export before clearing. Cross-tab recording is deliberately out of scope for the first implementation.

## Screenshot and evidence engine

`captureVisibleTab` captures the current viewport, recompresses to a bounded 1,440-pixel maximum dimension, and associates a screenshot reference with the current step. The record contains capture time, URL, step number, and image data. Limit captures and warn about local storage; large-page full-page stitching and video are not included.

Evidence reports assemble tester/session/application metadata, status, steps, values, locators, URLs, timestamps, notes, screenshot references, and a count-based execution summary. DOCX embeds available JPEG screenshots; XLSX includes Session, Recorded Steps, and Screenshots sheets with embedded images; PDF creates a basic chronological report with JPEGs where attached; JSON preserves the full session; CSV supports step review. These custom, dependency-free document writers are pragmatic prototype exporters, not Office/PDF conformance libraries; validate generated files in target Word/Excel/PDF readers before a regulated release. The HTML report can be printed/saved to PDF if a browser-native rendering is preferred.

An evidence export is not signed or tamper-evident. Production evidence should add cryptographic hashes, immutable audit events, trustworthy clock metadata, retention controls, source version, export manifest, and verified document-rendering libraries.

## Groq and test-case generation

The user configures their Groq model, temperature, language (US/UK/Indian English), maximum cases, reasoning preference, coverage categories, design techniques, and optional screenshots. The API key remains in local extension storage and is sent only in a direct HTTPS request to `api.groq.com`. The key is not encrypted by extension storage; local-device access can expose it. Use a dedicated, revocable key with restricted spend/rotation. No server-side proxy, key vault, or enterprise secret management is included.

Prompt inputs are limited to session metadata, captured actions, the currently accessible page's visible headings/controls, and optional tester-approved images. The prompt requires exact source step numbers, an allowlist of configured categories, concrete imperative steps, and explicit uncertainty for unobserved results. Schema checks reject malformed cases and references to nonexistent steps. The tester selects the screenshots/model compatibility; image support is model-dependent.

**No prompt can guarantee that a generative model never hallucinates.** This implementation reduces that risk through constrained context, source-step validation, reviewer-facing expected-result warnings, and TODOs. It cannot prove a suggested negative/boundary workflow exists; test ideas must be reviewed against product requirements and executed behavior.

Generated test cases can be exported from the Test Case Studio as an XLSX workbook with a summary sheet and a row-per-case sheet containing steps, expected result, priority, coverage, and journey-step traceability. The existing JSON export remains available.

### Coverage, prioritization, and validation rules

Coverage options include functional, positive, negative, edge, boundary, validation, UI, accessibility, security, and usability. Techniques include boundary value analysis, equivalence partitioning, decision tables, state transitions, error guessing, pairwise, exploratory, and risk-based testing. Ask for these only when the captured fields, values, controls, or states support a concrete scenario; otherwise label it as a proposed exploration rather than observed functionality.

The current model supplies High/Medium/Low priority; the client normalizes unknown values to Medium. A production prioritizer should compute a transparent score from business criticality, failure impact, likelihood, exposure, and evidence confidence, and show the factors. Validate required title/steps/expected result, category allowlist, priority enum, maximum count, step references, length bounds, duplicate cases, and sensitive output. Expected results unsupported by the session must remain explicitly unverified.

## Playwright generation

The automation builder supports select-all and individual reviewed cases. Priority, category, coverage, and text filters make the review table usable. The downloadable ZIP contains:

```text
test-master-playwright/
├── tests/journey.spec.ts
├── pages/JourneyPage.ts
├── components/FormComponents.ts
├── test-data/journey.data.ts
├── utils/README.txt
├── playwright.config.ts
└── package.json
```

Naming convention: `TC-###` for cases; `journey.spec.ts` for journey suites; PascalCase page classes; descriptive test titles. Page objects centralize reusable locators; tests use Playwright `test`, `expect`, role/label/attribute locators, and web-first assertions where outcomes are known. Recorded action values are example data, not production credentials.

The generated project intentionally marks unknown or unsupported actions/outcomes as TODO/review notes. The current scaffold does not synthesize every assertion or a generalized reusable component library. Before running it: set `BASE_URL`, install the pinned-compatible Playwright toolchain, verify selectors and test data, add explicit expected-state assertions from product requirements, and run tests in a controlled environment. Do not treat generated tests as verified automation.

## Security and privacy

* **Least privilege:** no `<all_urls>` host access, remote code, eval, or analytics. `activeTab` plus `scripting` injects only after the user starts a session.
* **Network:** the Groq API is the only declared host. Do not transmit screenshots or DOM without the user's explicit AI request and image toggle.
* **Secrets:** local extension storage is not encryption or a managed vault. Do not commit keys or expose them in shared profiles. Rotate/revoke keys if exposed.
* **Page content:** minimize data to labels, selected attributes, action values, and visible control summaries. Never collect password values; user review is still required for PII in notes, non-sensitive fields, screenshots, and exports.
* **Injection:** treat page text and AI responses as untrusted data; render with text nodes/escaped HTML, do not evaluate generated code, and inspect package contents before running.
* **Retention:** clear or export the active local session explicitly. A product version should define retention, deletion, enterprise policies, and device backup behavior.

## Technology, performance, and scale

Current stack: Manifest V3; vanilla JavaScript; Chrome/Edge `chrome.*` extension APIs; Groq OpenAI-compatible chat completions; hand-built minimal OOXML/PDF exporters; browser downloads. There are no frontend/export packages to install. A production build should prefer supported TypeScript, schema validators, maintained DOCX/XLSX/PDF libraries bundled locally, and a Playwright generator tested against its supported framework versions.

Performance measures: delegate events instead of per-node listeners, debounce text changes, cap sessions/screenshots, compress viewport images, keep worker stateless between events, serialize storage writes, and avoid sending screenshots unless selected. The present single-session, browser-local model does not provide team-scale synchronization. Scale later with a backend only after defining authentication, tenant isolation, consent, encryption, data residency, retention, audit, and key management.

## MVP roadmap and implementation phases

1. **Modern UI foundation (included):** side panel, responsive navigation, dashboard, theme, settings, accessibility/live toasts.
2. **Recording engine (included prototype):** action capture, state controls, locators, redaction heuristics, local session timeline.
3. **Evidence engine (included prototype):** viewport capture, session association, DOCX/PDF/XLSX/JSON/CSV exports.
4. **AI test studio (included prototype):** Groq configuration, bounded prompt, coverage/design inputs, reference/schema validation, manual review.
5. **Automation generator (included scaffold):** per-case selection, page-object starter, TypeScript test/data/config files, downloadable ZIP, TODO markers.
6. **Enterprise hardening (next):** automated browser/API tests, MV3 permission/lifecycle matrix, accessibility audit, production document libraries, PII controls, import/archive management, schema migration, key rotation/policy, localization, and security review.

Future opportunities, subject to explicit validation and product scope: self-healing locator suggestions (never silent substitution), AI test-data generation, Selenium/Cypress exporters, Jira/Azure DevOps/TestRail integrations, AI-assisted execution, and defect creation. These are not present in the current extension and require separate authorization, data-protection, and quality controls.

## Verification checklist

* Load the folder unpacked in current Chrome and Edge releases; verify the action opens the side panel.
* On a test page, exercise each supported event, pause/resume/stop/reset, a same-origin route change, and a cross-origin route change.
* Check redaction and ensure screenshot captures attach to the intended step.
* Validate DOCX/XLSX archives and their XML parts; open DOCX, XLSX, and PDF in supported readers and inspect screenshot orientation/scale.
* Use a restricted test Groq key; test malformed/model-error responses, no-evidence behavior, model/image incompatibility, and screenshots-off by default.
* Review generated locators and expected results; install/run the generated Playwright project only against a non-production environment.

