(() => {
  if (window.__traceQaInstalled) return;
  window.__traceQaInstalled = true;

  let enabled = false;
  let paused = false;
  let sessionId = null;
  const clean = (value, limit = 180) => String(value || "").replace(/\s+/g, " ").trim().slice(0, limit);
  const labelFor = (element) => {
    const aria = element.getAttribute("aria-label");
    const labelled = element.labels && Array.from(element.labels).map((label) => label.innerText).join(" ");
    const title = element.getAttribute("title");
    const placeholder = element.getAttribute("placeholder");
    const text = element.innerText || element.value;
    return clean(aria || labelled || element.getAttribute("name") || element.id || placeholder || title || text || element.tagName.toLowerCase());
  };
  const locatorCandidates = (element) => {
    const candidates = [];
    if (element.id) candidates.push(`#${CSS.escape(element.id)}`);
    const label = element.getAttribute("aria-label");
    if (label) candidates.push(`[aria-label="${label.replace(/["\\]/g, "\\$&")}"]`);
    const name = element.getAttribute("name");
    if (name) candidates.push(`${element.tagName.toLowerCase()}[name="${name.replace(/["\\]/g, "\\$&")}"]`);
    const role = element.getAttribute("role");
    if (role) candidates.push(`[role="${role}"]`);
    if (element.tagName === "BUTTON" || element.tagName === "A") {
      const text = clean(element.innerText, 80);
      if (text) candidates.push(`${element.tagName.toLowerCase()}:has-text("${text.replace(/["\\]/g, "\\$&")}")`);
    }
    return [...new Set(candidates)].slice(0, 5);
  };
  const attributesFor = (element) => {
    const keys = ["id", "name", "type", "role", "aria-label", "placeholder", "href", "data-testid"];
    return { tagName: element.tagName, ...Object.fromEntries(keys.filter((key) => element.hasAttribute(key)).map((key) => [key, clean(element.getAttribute(key), 240)])) };
  };
  const sensitive = (element) => /password|secret|token|card|cvv|otp|one-time-code/i.test(
    [element.type, element.name, element.id, element.autocomplete, element.getAttribute("placeholder")].join(" ")
  ) || element.type === "password";
  const reportError = (error) => {
    chrome.runtime.sendMessage({
      type: "QA_CONTENT_ERROR",
      sessionId,
      message: `Could not save a recorded action: ${error.message || "extension communication failed"}`
    }).catch((reportFailure) => console.error("Test Master could not report a recording error.", reportFailure));
  };
  const sendAction = async (action) => {
    try {
      const response = await chrome.runtime.sendMessage({ type: "QA_ACTION", action });
      if (!response || !response.ok) reportError(new Error(response && response.error || "extension did not acknowledge the action"));
    } catch (error) {
      reportError(error);
    }
  };
  const emit = (type, element, extra = {}) => {
    if (!enabled || paused || !element || !(element instanceof Element)) return;
    const textValue = element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement
      ? element.value : "";
    sendAction({
        sessionId,
        type,
        elementLabel: labelFor(element),
        elementText: clean(element.innerText || element.textContent),
        attributes: attributesFor(element),
        preferredLocator: locatorCandidates(element)[0] || element.tagName.toLowerCase(),
        alternateLocators: locatorCandidates(element).slice(1),
        value: textValue ? (sensitive(element) ? "[redacted]" : clean(textValue, 300)) : undefined,
        url: location.href,
        ...extra
    });
  };
  const closestTarget = (target) => target instanceof Element ? target.closest("button,a,input,textarea,select,[role=button],[role=link],[role=checkbox],[role=radio],[draggable=true]") || target : null;

  const inputTimers = new WeakMap();
  const lastInputValues = new WeakMap();
  document.addEventListener("click", (event) => {
    const element = closestTarget(event.target);
    if (!element) return;
    const type = element instanceof HTMLInputElement && element.type === "checkbox" ? "Checkbox Selection"
      : element instanceof HTMLInputElement && element.type === "radio" ? "Radio Selection"
        : element instanceof HTMLSelectElement ? null : "Click";
    if (type) emit(type, element);
  }, true);
  document.addEventListener("dblclick", (event) => emit("Double Click", closestTarget(event.target)), true);
  document.addEventListener("contextmenu", (event) => emit("Right Click", closestTarget(event.target)), true);
  document.addEventListener("input", (event) => {
    const el = event.target;
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      if (el.type === "checkbox" || el.type === "radio" || el.type === "file") return;
      clearTimeout(inputTimers.get(el));
      inputTimers.set(el, setTimeout(() => {
        const value = el.value;
        if (lastInputValues.get(el) !== value) {
          lastInputValues.set(el, value);
          emit("Text Input", el);
        }
      }, 500));
    }
  }, true);
  document.addEventListener("change", (event) => {
    const el = event.target;
    if (el instanceof HTMLSelectElement) emit("Dropdown Selection", el);
    if (el instanceof HTMLInputElement && el.type === "date") emit("Date Selection", el);
    if ((el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) && !["date", "checkbox", "radio", "file"].includes(el.type)) {
      clearTimeout(inputTimers.get(el));
      if (lastInputValues.get(el) !== el.value) {
        lastInputValues.set(el, el.value);
        emit("Text Input", el);
      }
    }
    if (el instanceof HTMLInputElement && el.type === "file") emit("File Upload", el, { value: `${el.files ? el.files.length : 0} file(s)` });
  }, true);
  document.addEventListener("keydown", (event) => {
    if (["Enter", "Tab", "Escape", "ArrowUp", "ArrowDown", " "].includes(event.key)) {
      emit("Keyboard Action", closestTarget(event.target), { key: event.key, modifiers: { alt: event.altKey, ctrl: event.ctrlKey, meta: event.metaKey, shift: event.shiftKey } });
    }
  }, true);
  document.addEventListener("submit", (event) => {
    const form = event.target;
    if (form instanceof HTMLFormElement) emit("Form Submission", form);
  }, true);
  document.addEventListener("dragend", (event) => emit("Drag & Drop", closestTarget(event.target)), true);
  document.addEventListener("drop", (event) => emit("Drag & Drop", closestTarget(event.target)), true);
  window.addEventListener("popstate", () => emitNavigation("History Navigation"));
  const originalPushState = history.pushState;
  history.pushState = function (...args) {
    const result = originalPushState.apply(this, args);
    emitNavigation("Navigation");
    return result;
  };
  const emitNavigation = (type) => {
    if (!enabled || paused) return;
    sendAction({ sessionId, type, elementLabel: document.title, elementText: "", attributes: {}, preferredLocator: "page", alternateLocators: [], url: location.href });
  };

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "QA_CONTENT_START") { enabled = true; paused = false; sessionId = message.sessionId; }
    if (message.type === "QA_CONTENT_PAUSE") paused = true;
    if (message.type === "QA_CONTENT_RESUME") paused = false;
    if (message.type === "QA_CONTENT_STOP") { enabled = false; paused = false; }
  });
})();
