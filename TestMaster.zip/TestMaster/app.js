(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const send = async (type, extra = {}) => {
    const response = await chrome.runtime.sendMessage({ type, ...extra });
    if (!response || !response.ok) throw new Error(response && response.error || "The extension could not complete that request.");
    return response;
  };
  const state = { session: null, cases: [], settings: {}, view: "overview", timelineFilter: "all", selected: new Set(), caseFilter: "all", codeFiles: null, startedAt: 0 };
  const defaults = {
    model: "llama-3.3-70b-versatile", temperature: 0.2, language: "US English", maxCases: 10,
    reasoning: "Medium", includeScreenshots: false,
    categories: ["Functional", "Positive", "Negative", "Edge case", "Boundary", "Validation"],
    techniques: ["Boundary Value Analysis", "Equivalence Partitioning"]
  };
  const icons = {
    "Click": "↗", "Double Click": "↗", "Right Click": "↗", "Keyboard Action": "⌨",
    "Text Input": "T", "Dropdown Selection": "⌄", "Checkbox Selection": "☑", "Radio Selection": "◉",
    "Date Selection": "▦", "File Upload": "↑", "Navigation": "↗", "History Navigation": "↶",
    "Form Submission": "✓", "Drag & Drop": "⠿"
  };
  const viewLabels = { overview: "Overview", journey: "Journey recorder", cases: "Test cases", automation: "Automation", evidence: "Evidence", settings: "Settings" };
  const formatTime = (date) => {
    if (!date) return "—";
    return new Date(date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  };
  const safe = (value) => String(value == null ? "" : value);
  const escapeHtml = (value) => safe(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
  function toast(message, error = false) {
    const item = document.createElement("div");
    item.className = `toast${error ? " error" : ""}`;
    item.textContent = message;
    $("#toast-region").append(item);
    setTimeout(() => item.remove(), 3500);
  }
  async function run(action, successMessage) {
    try { await action(); if (successMessage) toast(successMessage); }
    catch (error) { toast(error.message || "Something went wrong.", true); }
  }
  function currentSession() {
    if (!state.session) state.session = { name: "", tester: "", notes: "", steps: [], screenshots: [], status: "ready" };
    return state.session;
  }
  function openView(name) {
    state.view = name;
    $$(".view").forEach((view) => view.classList.toggle("active", view.id === `view-${name}`));
    $$(".nav-item[data-view]").forEach((button) => button.classList.toggle("active", button.dataset.view === name));
    $("#crumb").textContent = viewLabels[name] || "Overview";
    if (name === "automation") renderAutomation();
    if (name === "cases") renderCases();
    if (name === "evidence") renderEvidence();
    if (name === "journey") renderSessionFields();
  }
  function renderSessionFields() {
    const session = currentSession();
    const name = $("#session-name");
    const tester = $("#tester-name");
    const notes = $("#session-notes");
    if (document.activeElement !== name) name.value = session.name || "";
    if (document.activeElement !== tester) tester.value = session.tester || "";
    if (document.activeElement !== notes) notes.value = session.notes || "";
    $("#application-info").textContent = session.applicationTitle || session.applicationUrl || "Not connected";
    $("#started-info").textContent = session.startedAt ? new Date(session.startedAt).toLocaleString() : "—";
    $("#screenshot-info").textContent = `${(session.screenshots || []).length} capture${(session.screenshots || []).length === 1 ? "" : "s"}`;
  }
  function stepDescription(step) {
    const value = step.value && step.value !== "[redacted]" ? ` · ${step.value}` : step.value === "[redacted]" ? " · sensitive value redacted" : "";
    return `${step.elementLabel || step.elementText || "Page interaction"}${value}`;
  }
  function renderTimeline(target, steps, mini = false) {
    if (!steps.length) {
      target.innerHTML = mini
        ? `<div class="empty-state"><span class="empty-icon">◎</span><strong>Your next great test starts here</strong><p>Start recording, then interact with the page you want to test.</p></div>`
        : `<div class="empty-state timeline-empty"><span class="empty-icon">◎</span><strong>Your timeline is ready</strong><p>Start recording, then interact with the active browser tab. Steps appear here as they happen.</p></div>`;
      return;
    }
    const limited = steps.slice(-6).reverse();
    target.innerHTML = limited.map((step) => `
      <div class="timeline-item"><span class="step-marker">${escapeHtml(icons[step.type] || "•")}</span>
      <div class="step-content"><div class="step-title">${escapeHtml(step.type)} <span class="step-badge">#${step.stepNumber}</span></div>
      <div class="step-description" title="${escapeHtml(stepDescription(step))}">${escapeHtml(stepDescription(step))}</div>
      <div class="step-meta"><span>${escapeHtml(step.preferredLocator || "page action")}</span>${step.value === "[redacted]" ? "<span>🔒 redacted</span>" : ""}${(step.screenshotIds || []).length ? `<span class="step-shot">▧ screenshot</span>` : ""}</div></div>
      <span class="step-time">${escapeHtml(formatTime(step.timestamp))}</span></div>`).join("");
  }
  function getFilteredSteps() {
    const steps = currentSession().steps || [];
    if (state.timelineFilter === "navigation") return steps.filter((step) => /navigation/i.test(step.type));
    if (state.timelineFilter === "interactions") return steps.filter((step) => !/navigation/i.test(step.type));
    return steps;
  }
  function renderTimelineViews() {
    const session = currentSession();
    const steps = session.steps || [];
    renderTimeline($("#timeline"), getFilteredSteps());
    renderTimeline($("#overview-timeline"), steps, true);
    $("#timeline-count").textContent = steps.length;
    $("#footer-step-count").textContent = steps.length;
    $("#timeline-footer-label").textContent = steps.length ? `${steps.length} action${steps.length === 1 ? "" : "s"} captured` : "Waiting for your first interaction";
    $("#journey-subtitle").textContent = steps.length ? `${session.name || "Untitled journey"} · ${steps.length} recorded step${steps.length === 1 ? "" : "s"}` : "Record a real workflow to get started.";
    $("#nav-steps").textContent = steps.length;
    $("#metric-steps").textContent = steps.length;
    $("#metric-cases").textContent = state.cases.length;
    $("#metric-evidence").textContent = (session.screenshots || []).length;
    $("#metric-session").textContent = session.name || (steps.length ? "Latest recorded journey" : "No active journey yet");
    const status = session.status || "ready";
    $("#metric-status").textContent = status === "recording" ? "Recording" : status === "paused" ? "Paused" : status === "stopped" ? "Complete" : "Ready";
    const chip = $("#session-chip");
    chip.className = `session-chip ${status}`;
    chip.querySelector("span").textContent = status === "recording" ? "RECORDING" : status === "paused" ? "PAUSED" : status === "stopped" ? "SESSION COMPLETE" : "READY TO RECORD";
    $("#record-toggle").innerHTML = status === "recording" ? "⏺ <span>Recording</span>" : status === "paused" ? "⏺ <span>Resume</span>" : "⏺ <span>Start</span>";
    $("#record-toggle").disabled = status === "recording";
    $("#pause-toggle").disabled = !["recording", "paused"].includes(status);
    $("#pause-toggle").innerHTML = status === "paused" ? "▶ <span>Resume</span>" : "Ⅱ <span>Pause</span>";
    $("#stop-recording").disabled = !["recording", "paused"].includes(status);
    $("#recorder-title").textContent = status === "recording" ? "Recording your browser journey." : status === "paused" ? "Recording paused." : status === "stopped" ? "Your journey is ready to review." : "Your journey, in real time.";
    $("#recorder-copy").textContent = session.interruption && status === "paused" ? session.interruption : session.lastError || "Start recording, then interact with the active browser tab. Sensitive fields are automatically redacted.";
    $("#nav-cases").textContent = state.cases.length;
    renderSessionFields();
    renderCases();
    renderEvidence();
    renderAutomation();
  }
  function renderCases() {
    const body = $("#cases-body");
    if (!body) return;
    const query = ($("#case-search")?.value || "").trim().toLowerCase();
    const priority = $("#priority-filter")?.value || "all";
    const category = $("#category-filter")?.value || "all";
    const coverage = $("#coverage-filter")?.value || "all";
    const visible = state.cases.filter((item) => {
      const text = `${item.title} ${item.category} ${item.expectedResult}`.toLowerCase();
      return (!query || text.includes(query)) && (priority === "all" || item.priority === priority)
        && (category === "all" || item.category === category)
        && (coverage === "all" || item.coverageType === coverage);
    });
    $("#cases-empty").classList.toggle("visible", state.cases.length === 0);
    $("#export-cases-xlsx").disabled = state.cases.length === 0;
    body.innerHTML = visible.map((item) => `<tr><td><input type="checkbox" class="case-select" data-case-id="${escapeHtml(item.id)}" ${state.selected.has(item.id) ? "checked" : ""} aria-label="Select ${escapeHtml(item.title)}"></td><td>${escapeHtml(item.id)} · ${escapeHtml(item.title)}${item.requiresReview ? `<div class="trace-tag">Review expected result</div>` : ""}</td><td><span class="category-tag">${escapeHtml(item.category || "Functional")}</span></td><td><span class="priority-tag ${escapeHtml((item.priority || "medium").toLowerCase())}">${escapeHtml(item.priority || "Medium")}</span></td><td>${Array.isArray(item.steps) ? item.steps.length : 0} steps</td><td><span class="trace-tag">${(item.sourceStepNumbers || []).length ? "Journey steps " + escapeHtml(item.sourceStepNumbers.join(", ")) : "Needs review"}</span></td></tr>`).join("");
    $("#case-count-label").textContent = `${visible.length} of ${state.cases.length} test case${state.cases.length === 1 ? "" : "s"}`;
    $("#selection-label").textContent = `${state.selected.size} selected for automation`;
    $("#select-all-cases").checked = visible.length > 0 && visible.every((item) => state.selected.has(item.id));
    renderAutomation();
  }
  function selectedCases() {
    return state.cases.filter((item) => state.selected.has(item.id));
  }
  function renderAutomation() {
    const list = $("#automation-list");
    if (!list) return;
    list.innerHTML = state.cases.map((item) => `<label class="automation-case-row"><input type="checkbox" class="automation-select" data-case-id="${escapeHtml(item.id)}" ${state.selected.has(item.id) ? "checked" : ""}><span><strong>${escapeHtml(item.id)} · ${escapeHtml(item.title)}</strong><small>${(item.sourceStepNumbers || []).length} linked journey step(s) · ${escapeHtml(item.priority || "Medium")} priority</small></span><span class="category-tag">${escapeHtml(item.category || "Functional")}</span></label>`).join("");
    $("#automation-empty").classList.toggle("visible", state.cases.length === 0);
    const chosen = selectedCases();
    $("#code-preview-label").textContent = chosen.length ? `${chosen.length} selected test case${chosen.length === 1 ? "" : "s"} · TypeScript` : "Select cases to preview the generated test structure.";
    if (chosen.length && !state.codeFiles) makeProject();
    $("#code-preview").textContent = state.codeFiles ? state.codeFiles["tests/journey.spec.ts"] : "// Your Playwright test preview will appear here.";
  }
  function renderEvidence() {
    if (!$("#evidence-list")) return;
    const session = currentSession();
    $("#evidence-session-name").textContent = session.name || "Untitled journey";
    $("#evidence-app-name").textContent = session.applicationTitle || session.applicationUrl || "Application not recorded";
    $("#evidence-steps").textContent = (session.steps || []).length;
    $("#evidence-shots").textContent = (session.screenshots || []).length;
    $("#evidence-tester").textContent = session.tester || "Not specified";
    $("#evidence-created").textContent = session.startedAt ? `Started ${new Date(session.startedAt).toLocaleString()}` : "No session created";
    const shots = new Map((session.screenshots || []).map((shot) => [shot.id, shot]));
    const rows = (session.steps || []).slice().reverse();
    $("#evidence-list").innerHTML = rows.length ? rows.map((step) => {
      const shot = (step.screenshotIds || []).map((id) => shots.get(id)).find(Boolean);
      return `<div class="evidence-row"><span class="step-marker">${escapeHtml(icons[step.type] || "•")}</span><span><strong>${step.stepNumber}. ${escapeHtml(step.type)} · ${escapeHtml(step.elementLabel || "Page action")}</strong><small>${escapeHtml(formatTime(step.timestamp))} · ${escapeHtml(step.url || "")}${step.value === "[redacted]" ? " · sensitive value redacted" : ""}</small></span>${shot ? `<img src="${shot.dataUrl}" alt="Screenshot for step ${step.stepNumber}">` : "<span></span>"}</div>`;
    }).join("") : `<div class="evidence-empty">No recorded steps yet. Start a journey and capture a screenshot to build your report.</div>`;
  }
  async function saveSessionFields() {
    if (!state.session) return;
    state.session.name = $("#session-name").value.trim();
    state.session.tester = $("#tester-name").value.trim();
    state.session.notes = $("#session-notes").value.trim();
    state.session.updatedAt = new Date().toISOString();
    await send("QA_SAVE_SESSION", { session: state.session });
    renderTimelineViews();
  }
  async function startRecording() {
    if (state.session && (state.session.steps || []).length && !confirm("Start a new session? The current session will be replaced. Export it first to keep its evidence.")) return;
    const response = await send("QA_START");
    state.session = response.session;
    state.selected.clear();
    state.codeFiles = null;
    renderTimelineViews();
    openView("journey");
    toast("Recording started on the active browser tab.");
  }
  async function controlRecording(type) {
    const response = await send(type);
    state.session = response.session;
    renderTimelineViews();
    toast(type === "QA_STOP" ? "Recording stopped. Your journey is ready to review." : type === "QA_PAUSE" ? "Recording paused." : "Recording resumed.");
  }
  async function captureScreenshot() {
    const response = await send("QA_CAPTURE");
    state.session = response.session;
    renderTimelineViews();
    toast(`Screenshot attached to step ${response.screenshot.stepNumber || "—"}.`);
  }
  function settingsFromForm() {
    return {
      ...state.settings,
      model: $("#ai-model").value,
      temperature: Number($("#ai-temperature").value),
      language: $("#output-language").value,
      maxCases: Number($("#max-cases").value),
      reasoning: $("#reasoning-effort").value,
      includeScreenshots: $("#include-screenshots").checked,
      categories: $$(".coverage-grid input:checked").map((input) => input.value),
      techniques: Array.from($("#design-techniques").selectedOptions).map((option) => option.value)
    };
  }
  function populateSettings() {
    const settings = { ...defaults, ...state.settings };
    $("#groq-key").value = settings.groqApiKey || "";
    $("#ai-model").value = settings.model;
    $("#ai-temperature").value = settings.temperature;
    $("#temperature-value").textContent = Number(settings.temperature).toFixed(1);
    $("#output-language").value = settings.language;
    $("#max-cases").value = String(settings.maxCases);
    $("#reasoning-effort").value = settings.reasoning;
    $("#include-screenshots").checked = !!settings.includeScreenshots;
    $$(".coverage-grid input").forEach((input) => { input.checked = settings.categories.includes(input.value); });
    const techniques = new Set(settings.techniques);
    Array.from($("#design-techniques").options).forEach((option) => { option.selected = techniques.has(option.value); });
  }
  function normalizeCategory(value) {
    const text = safe(value).toLowerCase();
    const known = ["functional", "positive", "negative", "edge case", "boundary", "validation", "ui", "accessibility", "security", "usability"];
    return known.find((item) => text.includes(item)) || "Functional";
  }
  function normalizeCoverage(value, category) {
    const text = safe(value || category).toLowerCase();
    const known = [["happy path", "Happy path"], ["negative", "Negative"], ["edge case", "Edge case"], ["boundary", "Boundary"], ["validation", "Validation"], ["ui", "UI"], ["accessibility", "Accessibility"], ["functional", "Functional"]];
    const found = known.find(([key]) => text.includes(key));
    return found ? found[1] : "Functional";
  }
  function parseCases(result, maxCases, sourceSteps) {
    let data;
    try { data = JSON.parse(result); } catch { throw new Error("The AI response was not valid JSON. Try again or choose another model."); }
    if (!data || !Array.isArray(data.testCases)) throw new Error("The AI response did not contain a testCases array.");
    const allowedSteps = new Set(sourceSteps.map((step) => step.stepNumber));
    const cases = data.testCases.slice(0, maxCases).map((item, index) => {
      if (!item || typeof item.title !== "string" || !Array.isArray(item.steps) || !item.steps.length || typeof item.expectedResult !== "string") return null;
      const refs = Array.isArray(item.sourceStepNumbers) ? item.sourceStepNumbers.filter((number) => allowedSteps.has(Number(number))).map(Number) : [];
      if (!refs.length) return null;
      return {
        id: `TC-${String(index + 1).padStart(3, "0")}`,
        title: item.title.slice(0, 180),
        category: normalizeCategory(item.category),
        coverageType: normalizeCoverage(item.coverageType, item.category),
        priority: ["High", "Medium", "Low"].find((value) => value.toLowerCase() === safe(item.priority).toLowerCase()) || "Medium",
        steps: item.steps.slice(0, 20).map((step) => safe(step).slice(0, 300)),
        expectedResult: item.expectedResult.slice(0, 700),
        sourceStepNumbers: [...new Set(refs)],
        requiresReview: true
      };
    }).filter(Boolean);
    if (!cases.length) throw new Error("No grounded test cases passed validation. Ensure the journey has captured steps and try again.");
    return cases;
  }
  async function generateCases() {
    const session = currentSession();
    if (!session.steps.length) throw new Error("Record at least one browser interaction before generating test cases.");
    const settings = { ...defaults, ...state.settings };
    if (!settings.groqApiKey) { openView("settings"); throw new Error("Add your Groq API key in Settings before generating test cases."); }
    const { snapshot } = await send("QA_GET_DOM");
    const selectedSteps = session.steps.map((step) => ({
      stepNumber: step.stepNumber, action: step.type, label: step.elementLabel,
      text: step.elementText, value: step.value, url: step.url, timestamp: step.timestamp,
      locator: step.preferredLocator, attributes: step.attributes
    }));
    const system = `You are a senior QA engineer. Create concrete, imperative manual test-case drafts using ONLY the supplied observed actions and visible DOM snapshot. Do not invent controls, navigation, APIs, success messages, business rules, field constraints, or outcomes. If an expected outcome is not observed or specified, state that it requires product-owner confirmation; never assert it as a fact. Do not create tests for controls absent from the snapshot or journey. Every case must cite one or more exact observed sourceStepNumbers. Return ONLY a JSON object with summary and testCases. Each test case: {title, category, coverageType, priority, steps, expectedResult, sourceStepNumbers}. Categories allowed: ${settings.categories.join(", ") || "Functional"}. Use design techniques where supported by captured evidence: ${settings.techniques.join(", ") || "none selected"}. Output language: ${settings.language}. Reasoning effort: ${settings.reasoning}. Maximum cases: ${settings.maxCases}. Priority is High, Medium, or Low. Make unsupported variations explicit as requiring exploration, not observed product behavior.`;
    const userText = `SESSION METADATA\n${JSON.stringify({ name: session.name, application: session.applicationTitle, url: session.applicationUrl, notes: session.notes })}\n\nRECORDED ACTIONS\n${JSON.stringify(selectedSteps)}\n\nVISIBLE DOM SNAPSHOT\n${JSON.stringify(snapshot)}\n\nGenerate only executable drafts traceable to those exact labels and cited step numbers.`;
    const content = [{ type: "text", text: userText }];
    if (settings.includeScreenshots && session.screenshots.length) {
      for (const shot of session.screenshots.slice(-2)) content.push({ type: "image_url", image_url: { url: shot.dataUrl } });
    }
    const response = await send("QA_GROQ_REQUEST", {
      payload: {
        model: settings.model, temperature: settings.temperature,
        messages: [{ role: "system", content: system }, { role: "user", content }]
      }
    });
    state.cases = parseCases(response.result, Number(settings.maxCases) || 10, session.steps);
    state.selected.clear();
    state.codeFiles = null;
    await send("QA_SAVE_CASES", { cases: state.cases });
    renderTimelineViews();
    openView("cases");
    toast(`${state.cases.length} grounded test case draft${state.cases.length === 1 ? "" : "s"} generated. Review expected results before use.`);
  }
  function jsString(value) { return JSON.stringify(safe(value)); }
  function locatorExpression(step) {
    const attrs = step.attributes || {};
    if (attrs["data-testid"]) return `page.getByTestId(${jsString(attrs["data-testid"])})`;
    if (attrs.id) return `page.locator(${jsString(`#${attrs.id}`)})`;
    if (attrs.name && ["INPUT", "SELECT", "TEXTAREA"].includes(attrs.tagName)) return `page.locator(${jsString(`${attrs.tagName.toLowerCase()}[name="${attrs.name.replace(/"/g, '\\"')}"]`)})`;
    const label = step.elementLabel || "";
    const tag = (attrs.tagName || "").toLowerCase();
    if (label && ["input", "select", "textarea"].includes(tag)) return `page.getByLabel(${jsString(label)}, { exact: true })`;
    if (label && tag === "button") return `page.getByRole("button", { name: ${jsString(label)}, exact: true })`;
    if (label && tag === "a") return `page.getByRole("link", { name: ${jsString(label)}, exact: true })`;
    if (step.preferredLocator && !/has-text/.test(step.preferredLocator)) return `page.locator(${jsString(step.preferredLocator)})`;
    return `page.getByText(${jsString(label || step.elementText || "TODO: add a verified locator")}, { exact: true })`;
  }
  function makeProject() {
    const selected = selectedCases();
    const session = currentSession();
    const associated = new Map();
    for (const item of selected) for (const number of item.sourceStepNumbers || []) {
      const step = session.steps.find((entry) => entry.stepNumber === number);
      if (step) associated.set(number, step);
    }
    const ordered = [...associated.values()].sort((a, b) => a.stepNumber - b.stepNumber);
    const uniqueLocators = new Map();
    for (const step of ordered) uniqueLocators.set(step.stepNumber, locatorExpression(step));
    const pageLines = ordered.filter((step) => !/navigation/i.test(step.type)).map((step) => `  readonly step${step.stepNumber} = ${uniqueLocators.get(step.stepNumber)};`);
    const actions = ordered.map((step) => {
      const locator = `this.page.step${step.stepNumber}`;
      if (step.type === "Text Input" && step.value && step.value !== "[redacted]") return `    await ${locator}.fill(${jsString(step.value)});`;
      if (step.type === "Text Input") return `    // TODO: Supply a safe test value for step ${step.stepNumber}.`;
      if (["Click", "Double Click", "Form Submission"].includes(step.type)) return `    await ${locator}.click();`;
      if (step.type === "Dropdown Selection" && step.value) return `    await ${locator}.selectOption({ label: ${jsString(step.value)} });`;
      if (step.type === "Checkbox Selection" || step.type === "Radio Selection") return `    await ${locator}.check();`;
      if (step.type === "Keyboard Action" && step.key) return `    await ${locator}.press(${jsString(step.key)});`;
      if (step.type === "Navigation" && step.url) return `    await this.page.page.goto(${jsString(step.url)});`;
      return `    // TODO: Review and implement observed action: ${step.type} (journey step ${step.stepNumber}).`;
    });
    const testLines = selected.map((item) => {
      const refs = (item.sourceStepNumbers || []).map((number) => session.steps.find((step) => step.stepNumber === number)).filter(Boolean);
      const sourceCode = refs.map((step) => {
        const action = actions[ordered.indexOf(step)];
        return action && !/navigation/i.test(step.type) ? `    await expect(journey.step${step.stepNumber}).toBeVisible();\n${action}` : action;
      }).filter(Boolean);
      const unique = [...new Set(sourceCode)];
      const reviewNote = item.expectedResult.replace(/[\r\n]+/g, " ").replace(/\*\//g, "* /").slice(0, 150);
      return `  test(${jsString(`${item.id} ${item.title}`)}, async ({ page }) => {\n    const journey = new JourneyPage(page);\n${unique.join("\n") || "    // TODO: Map this test to verified recorded actions."}\n    // TODO: Verify this expected result against product requirements: ${reviewNote}\n  });`;
    }).join("\n\n");
    const files = {
      "package.json": JSON.stringify({ name: "test-master-playwright", private: true, scripts: { test: "playwright test" }, devDependencies: { "@playwright/test": "^1.50.0", typescript: "^5.7.0" } }, null, 2),
      "playwright.config.ts": `import { defineConfig, devices } from "@playwright/test";\n\nexport default defineConfig({\n  testDir: "./tests",\n  fullyParallel: true,\n  reporter: [["list"], ["html", { open: "never" }]],\n  use: { baseURL: process.env.BASE_URL, trace: "retain-on-failure", screenshot: "only-on-failure", ...devices["Desktop Chrome"] },\n  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }]\n});\n`,
      "pages/JourneyPage.ts": `import { expect, type Locator, type Page } from "@playwright/test";\n\nexport class JourneyPage {\n  constructor(readonly page: Page) {}\n${pageLines.length ? pageLines.join("\n") : "  // Select test cases to populate locators."}\n\n  async expectVisible(locator: Locator): Promise<void> {\n    await expect(locator).toBeVisible();\n  }\n}\n`,
      "components/FormComponents.ts": `import { expect, type Locator } from "@playwright/test";\n\nexport class FormComponents {\n  async fill(locator: Locator, value: string): Promise<void> {\n    await expect(locator).toBeVisible();\n    await locator.fill(value);\n  }\n\n  async select(locator: Locator, label: string): Promise<void> {\n    await expect(locator).toBeVisible();\n    await locator.selectOption({ label });\n  }\n\n  async check(locator: Locator): Promise<void> {\n    await expect(locator).toBeVisible();\n    await locator.check();\n  }\n}\n`,
      "test-data/journey.data.ts": `export const journeyData = {\n  startUrl: ${jsString(session.applicationUrl || "")},\n  cases: ${JSON.stringify(selected.map((item) => ({ id: item.id, title: item.title, sourceStepNumbers: item.sourceStepNumbers, expectedResult: item.expectedResult })), null, 2).split("\n").map((line) => "  " + line).join("\n")}\n} as const;\n`,
      "tests/journey.spec.ts": `import { test, expect } from "@playwright/test";\nimport { JourneyPage } from "../pages/JourneyPage";\nimport { journeyData } from "../test-data/journey.data";\n\ntest.describe("Recorded journey · human-reviewed drafts", () => {\n  test.beforeEach(async ({ page }) => {\n    if (journeyData.startUrl) await page.goto(journeyData.startUrl);\n  });\n\n${testLines || "  // Select one or more cases in Test Master to generate test drafts."}\n});\n`,
      "utils/README.txt": "Keep test helpers here. Add only reusable behavior verified for your application.\n"
    };
    state.codeFiles = files;
  }
  function saveFile(filename, mime, content) {
    const encoded = content instanceof Uint8Array
      ? TestMasterExports.dataUrl(content, mime)
      : `data:${mime};charset=utf-8,${encodeURIComponent(content)}`;
    return send("QA_DOWNLOAD", { filename, dataUrl: encoded });
  }
  async function exportEvidence(format) {
    const session = { ...currentSession(), exportedAt: new Date().toISOString() };
    const baseName = (session.name || "Test-Master-evidence").replace(/[^a-z0-9-_]+/gi, "-").replace(/^-|-$/g, "") || "Test-Master-evidence";
    if (format === "docx") await saveFile(`${baseName}.docx`, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", TestMasterExports.docx(session));
    else if (format === "xlsx") await saveFile(`${baseName}.xlsx`, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", TestMasterExports.xlsx(session));
    else if (format === "pdf") await saveFile(`${baseName}.pdf`, "application/pdf", TestMasterExports.pdf(session));
    else if (format === "csv") await saveFile(`${baseName}.csv`, "text/csv", TestMasterExports.csv(session));
    else if (format === "html") await saveFile(`${baseName}-evidence.html`, "text/html", TestMasterExports.evidenceHtml(session));
    else await saveFile(`${baseName}.json`, "application/json", TestMasterExports.json(session));
    toast(`${format.toUpperCase()} export prepared.`);
  }
  function generateProject() {
    const selected = selectedCases();
    if (!selected.length) throw new Error("Select at least one test case before generating a project.");
    makeProject();
    renderAutomation();
    toast(`${Object.keys(state.codeFiles).length} Playwright project files are ready.`);
  }
  async function downloadProject() {
    if (!selectedCases().length) throw new Error("Select at least one test case before downloading a project.");
    if (!state.codeFiles) makeProject();
    const archive = TestMasterExports.zip(Object.entries(state.codeFiles).map(([name, data]) => ({ name: `test-master-playwright/${name}`, data })));
    await saveFile("test-master-playwright.zip", "application/zip", archive);
    toast("Playwright project ZIP downloaded. Review TODOs before running.");
  }
  async function initialize() {
    const response = await send("QA_GET_STATE");
    state.session = response.session;
    state.cases = response.cases || [];
    state.settings = { ...defaults, ...response.settings };
    if (state.session) state.startedAt = new Date(state.session.startedAt || Date.now()).getTime();
    if (state.session && state.session.steps) {
      const last = state.session.steps[state.session.steps.length - 1];
      if (last && last.stepNumber !== state.session.steps.length) state.session.steps.forEach((step, index) => { step.stepNumber = index + 1; });
    }
    populateSettings();
    const theme = await chrome.storage.local.get("traceqa.theme");
    if (theme["traceqa.theme"] === "dark") document.body.classList.add("dark");
    $("#today").textContent = new Date().toLocaleDateString([], { weekday: "long", month: "short", day: "numeric" });
    renderTimelineViews();
    setInterval(() => {
      const started = state.session && state.session.startedAt ? new Date(state.session.startedAt).getTime() : 0;
      if (!started || !state.session || !["recording", "paused"].includes(state.session.status)) { $("#recording-duration").textContent = "00:00"; return; }
      const seconds = Math.max(0, Math.floor((Date.now() - started) / 1000));
      $("#recording-duration").textContent = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
    }, 1000);
  }
  document.addEventListener("click", (event) => {
    const nav = event.target.closest("[data-view]");
    if (nav) { openView(nav.dataset.view); return; }
    const go = event.target.closest("[data-go]");
    if (go) { openView(go.dataset.go); return; }
    const filter = event.target.closest(".filter-chip");
    if (filter) {
      state.timelineFilter = filter.dataset.filter;
      $$(".filter-chip").forEach((item) => item.classList.toggle("selected", item === filter));
      renderTimeline($("#timeline"), getFilteredSteps());
      return;
    }
    const exportButton = event.target.closest("[data-export]");
    if (exportButton) { run(() => exportEvidence(exportButton.dataset.export)); return; }
  });
  $("#start-main").addEventListener("click", () => run(startRecording));
  $("#record-toggle").addEventListener("click", () => {
    if (currentSession().status === "paused") run(() => controlRecording("QA_RESUME"));
    else run(startRecording);
  });
  $("#pause-toggle").addEventListener("click", () => run(() => controlRecording(currentSession().status === "paused" ? "QA_RESUME" : "QA_PAUSE")));
  $("#stop-recording").addEventListener("click", () => run(() => controlRecording("QA_STOP")));
  $("#reset-recording").addEventListener("click", () => run(async () => {
    if (!confirm("Reset this journey and remove its screenshots? Export first if you need a copy.")) return;
    await send("QA_RESET");
    state.session = null;
    state.selected.clear();
    state.codeFiles = null;
    renderTimelineViews();
    toast("Session reset.");
  }));
  $("#capture-shot").addEventListener("click", () => run(captureScreenshot));
  $("#capture-shot-evidence").addEventListener("click", () => run(captureScreenshot));
  $("#export-session").addEventListener("click", () => run(() => exportEvidence("json")));
  $("#generate-cases").addEventListener("click", () => run(generateCases));
  $("#notice-settings").addEventListener("click", () => openView("settings"));
  $("#export-cases").addEventListener("click", () => {
    const json = JSON.stringify({ summary: { count: state.cases.length, generatedAt: new Date().toISOString() }, testCases: state.cases }, null, 2);
    run(() => saveFile("test-master-test-cases.json", "application/json", json), "Test cases exported.");
  });
  $("#export-cases-xlsx").addEventListener("click", () => run(async () => {
    if (!state.cases.length) throw new Error("Generate test cases before exporting them.");
    const session = currentSession();
    const workbook = TestMasterExports.testCasesXlsx(state.cases, {
      generatedAt: new Date().toISOString(),
      sessionName: session.name,
      application: session.applicationTitle || session.applicationUrl
    });
    await saveFile("test-master-test-cases.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", workbook);
    toast("Test cases exported as XLSX.");
  }));
  $("#generate-code").addEventListener("click", () => run(async () => generateProject()));
  $("#download-project").addEventListener("click", () => run(downloadProject));
  $("#copy-code").addEventListener("click", () => run(async () => {
    if (!state.codeFiles) throw new Error("Select cases to generate a code preview first.");
    await navigator.clipboard.writeText(state.codeFiles["tests/journey.spec.ts"]);
    toast("Test preview copied.");
  }));
  $("#select-all-automation").addEventListener("click", () => {
    const allSelected = state.cases.length > 0 && state.cases.every((item) => state.selected.has(item.id));
    state.selected = new Set(allSelected ? [] : state.cases.map((item) => item.id));
    state.codeFiles = null;
    renderAutomation();
    renderCases();
  });
  $("#select-all-cases").addEventListener("change", (event) => {
    const visible = $$("#cases-body .case-select").map((input) => input.dataset.caseId);
    for (const id of visible) event.target.checked ? state.selected.add(id) : state.selected.delete(id);
    state.codeFiles = null;
    renderCases();
  });
  document.addEventListener("change", (event) => {
    if (event.target.matches(".case-select,.automation-select")) {
      event.target.checked ? state.selected.add(event.target.dataset.caseId) : state.selected.delete(event.target.dataset.caseId);
      state.codeFiles = null;
      renderCases();
    }
  });
  ["case-search", "priority-filter", "category-filter", "coverage-filter"].forEach((id) => {
    $(`#${id}`).addEventListener(id === "case-search" ? "input" : "change", renderCases);
  });
  for (const id of ["session-name", "tester-name", "session-notes"]) $(`#${id}`).addEventListener("blur", () => run(saveSessionFields));
  $("#save-settings").addEventListener("click", () => run(async () => {
    const settings = settingsFromForm();
    settings.groqApiKey = $("#groq-key").value.trim();
    await send("QA_SAVE_SETTINGS", { settings });
    state.settings = settings;
    toast("AI settings saved in this browser profile.");
  }));
  $("#ai-temperature").addEventListener("input", (event) => { $("#temperature-value").textContent = Number(event.target.value).toFixed(1); });
  $("#toggle-key").addEventListener("click", (event) => {
    const input = $("#groq-key");
    input.type = input.type === "password" ? "text" : "password";
    event.target.textContent = input.type === "password" ? "Show" : "Hide";
  });
  $("#clear-data").addEventListener("click", () => run(async () => {
    if (!confirm("Clear the saved journey, screenshots, and generated test cases from this browser?")) return;
    await chrome.storage.local.remove(["traceqa.session", "traceqa.cases"]);
    state.session = null;
    state.cases = [];
    state.selected.clear();
    state.codeFiles = null;
    renderTimelineViews();
    toast("Local session data cleared. AI settings were kept.");
  }));
  $("#theme-toggle").addEventListener("click", () => run(async () => {
    const dark = document.body.classList.toggle("dark");
    await chrome.storage.local.set({ "traceqa.theme": dark ? "dark" : "light" });
  }));
  $("#session-name").addEventListener("input", () => { if (state.session) { state.session.name = $("#session-name").value; $("#evidence-session-name").textContent = state.session.name || "Untitled journey"; } });
  $("#tester-name").addEventListener("input", () => { if (state.session) { state.session.tester = $("#tester-name").value; $("#evidence-tester").textContent = state.session.tester || "Not specified"; } });
  $("#session-notes").addEventListener("input", () => { if (state.session) state.session.notes = $("#session-notes").value; });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes["traceqa.session"]) state.session = changes["traceqa.session"].newValue || null;
    if (changes["traceqa.cases"]) state.cases = changes["traceqa.cases"].newValue || [];
    renderTimelineViews();
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message && message.type === "QA_CONTENT_ERROR") toast(message.message || "A recorded action could not be saved.", true);
  });
  run(initialize);
})();
