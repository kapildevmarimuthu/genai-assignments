(() => {
  const key = document.querySelector("#key");
  const model = document.querySelector("#model");
  const status = document.querySelector("#status");
  chrome.storage.local.get("traceqa.settings").then((data) => {
    const settings = data["traceqa.settings"] || {};
    key.value = settings.groqApiKey || "";
    if (settings.model) model.value = settings.model;
  }).catch((error) => { status.textContent = `Could not load settings: ${error.message}`; });
  document.querySelector("#toggle").addEventListener("click", (event) => {
    key.type = key.type === "password" ? "text" : "password";
    event.target.textContent = key.type === "password" ? "Show" : "Hide";
  });
  document.querySelector("#save").addEventListener("click", async () => {
    try {
      const current = (await chrome.storage.local.get("traceqa.settings"))["traceqa.settings"] || {};
      await chrome.storage.local.set({ "traceqa.settings": { ...current, groqApiKey: key.value.trim(), model: model.value } });
      status.textContent = "Settings saved to this browser profile.";
    } catch (error) {
      status.textContent = `Could not save settings: ${error.message}`;
    }
  });
})();
