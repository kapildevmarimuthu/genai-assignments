(() => {
  const encoder = new TextEncoder();
  const bytes = (value) => encoder.encode(value);
  const concat = (parts) => {
    const size = parts.reduce((sum, part) => sum + part.length, 0);
    const output = new Uint8Array(size);
    let offset = 0;
    for (const part of parts) { output.set(part, offset); offset += part.length; }
    return output;
  };
  const dataUrlBytes = (dataUrl) => {
    const raw = atob(dataUrl.split(",")[1] || "");
    const result = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) result[i] = raw.charCodeAt(i);
    return result;
  };
  const dataUrlBase64 = (dataUrl) => dataUrl.split(",")[1] || "";
  const xml = (value) => String(value == null ? "" : value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
  const ascii = (value) => String(value == null ? "" : value).normalize("NFKD").replace(/[^\x20-\x7E]/g, "?");
  const pdfString = (value) => ascii(value).replace(/([\\()])/g, "\\$1");

  function crc32(data) {
    let crc = -1;
    for (let i = 0; i < data.length; i++) {
      crc ^= data[i];
      for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
    return (crc ^ -1) >>> 0;
  }
  function u16(value) { return new Uint8Array([value & 255, (value >>> 8) & 255]); }
  function u32(value) { return new Uint8Array([value & 255, (value >>> 8) & 255, (value >>> 16) & 255, (value >>> 24) & 255]); }
  function zip(files) {
    const localParts = [];
    const centralParts = [];
    let offset = 0;
    for (const file of files) {
      const name = bytes(file.name);
      const content = typeof file.data === "string" ? bytes(file.data) : file.data;
      const crc = crc32(content);
      const header = concat([u32(0x04034b50), u16(20), u16(0x0800), u16(0), u16(0), u16(0), u32(crc), u32(content.length), u32(content.length), u16(name.length), u16(0), name]);
      localParts.push(header, content);
      centralParts.push(concat([u32(0x02014b50), u16(20), u16(20), u16(0x0800), u16(0), u16(0), u16(0), u32(crc), u32(content.length), u32(content.length), u16(name.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), name]));
      offset += header.length + content.length;
    }
    const central = concat(centralParts);
    return concat([...localParts, central, u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length), u32(central.length), u32(offset), u16(0)]);
  }
  function textParagraph(value, style) {
    const styleXml = style ? `<w:pPr><w:pStyle w:val="${style}"/></w:pPr>` : "";
    return `<w:p>${styleXml}<w:r><w:t xml:space="preserve">${xml(value)}</w:t></w:r></w:p>`;
  }
  function imageParagraph(relation) {
    return `<w:p><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="5486400" cy="3086100"/><wp:docPr id="${relation}" name="Evidence screenshot ${relation}"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="${relation}" name="screenshot-${relation}.jpg"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rId${relation}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="5486400" cy="3086100"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>`;
  }
  function docx(session) {
    const screenshots = new Map((session.screenshots || []).map((shot) => [shot.id, shot]));
    const files = [];
    const imageRels = [];
    let imageNumber = 0;
    let body = textParagraph("Test Master · Execution Evidence", "Title");
    body += textParagraph(`Session: ${session.name || "Untitled journey"}`);
    body += textParagraph(`Tester: ${session.tester || "Not specified"}    Application: ${session.applicationTitle || session.applicationUrl || "Not recorded"}`);
    body += textParagraph(`Started: ${session.startedAt || "Not recorded"}    Exported: ${new Date().toISOString()}`);
    body += textParagraph(`Execution summary: ${session.steps ? session.steps.length : 0} steps · ${session.screenshots ? session.screenshots.length : 0} screenshots · Status: ${session.status || "not recorded"}`, "Heading1");
    if (session.notes) body += textParagraph(`Notes: ${session.notes}`);
    body += textParagraph("Recorded steps", "Heading1");
    for (const step of session.steps || []) {
      body += textParagraph(`${step.stepNumber}. ${step.type} — ${step.elementLabel || step.elementText || "Page action"}`, "Heading2");
      body += textParagraph(`Timestamp: ${step.timestamp || "Not recorded"}    URL: ${step.url || ""}`);
      if (step.value) body += textParagraph(`Value: ${step.value}`);
      if (step.preferredLocator) body += textParagraph(`Preferred locator: ${step.preferredLocator}`);
      if (step.elementText) body += textParagraph(`Element text: ${step.elementText}`);
      for (const id of step.screenshotIds || []) {
        const shot = screenshots.get(id);
        if (!shot || !shot.dataUrl || !shot.dataUrl.startsWith("data:image/jpeg")) continue;
        imageNumber++;
        files.push({ name: `word/media/image${imageNumber}.jpg`, data: dataUrlBytes(shot.dataUrl) });
        imageRels.push(`<Relationship Id="rId${imageNumber}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image${imageNumber}.jpg"/>`);
        body += textParagraph(`Screenshot captured ${shot.capturedAt}`);
        body += imageParagraph(imageNumber);
      }
    }
    if (!(session.steps || []).length) body += textParagraph("No steps were recorded.");
    body += "<w:sectPr><w:pgSz w:w=\"12240\" w:h=\"15840\"/><w:pgMar w:top=\"720\" w:right=\"720\" w:bottom=\"720\" w:left=\"720\"/></w:sectPr>";
    files.push(
      { name: "[Content_Types].xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="jpg" ContentType="image/jpeg"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>` },
      { name: "_rels/.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>` },
      { name: "word/document.xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>${body}</w:body></w:document>` },
      { name: "word/_rels/document.xml.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>${imageRels.join("")}</Relationships>` },
      { name: "word/styles.xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="20"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:rPr><w:b/><w:sz w:val="26"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:rPr><w:b/><w:sz w:val="22"/></w:rPr></w:style></w:styles>` }
    );
    return zip(files);
  }
  function columnName(number) {
    let name = "";
    while (number > 0) { const remainder = (number - 1) % 26; name = String.fromCharCode(65 + remainder) + name; number = Math.floor((number - 1) / 26); }
    return name;
  }
  function worksheet(rows, hasDrawing = false) {
    const body = rows.map((row, rowIndex) => `<row r="${rowIndex + 1}">${row.map((cell, cellIndex) => `<c r="${columnName(cellIndex + 1)}${rowIndex + 1}" t="inlineStr"><is><t xml:space="preserve">${xml(cell)}</t></is></c>`).join("")}</row>`).join("");
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetData>${body}</sheetData>${hasDrawing ? '<drawing r:id="rIdDrawing"/>' : ""}</worksheet>`;
  }
  function xlsx(session) {
    const screenshots = session.screenshots || [];
    const imageFiles = screenshots.filter((shot) => shot.dataUrl && shot.dataUrl.startsWith("data:image/jpeg"));
    const drawingXml = imageFiles.map((shot, index) => {
      const row = index + 1;
      return `<xdr:twoCellAnchor><xdr:from><xdr:col>4</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${row}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>10</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${row + 8}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="${index + 1}" name="Evidence screenshot ${index + 1}"/><xdr:cNvPicPr/></xdr:nvPicPr><xdr:blipFill><a:blip r:embed="rId${index + 1}"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="5486400" cy="3086100"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:twoCellAnchor>`;
    }).join("");
    const files = [
      { name: "[Content_Types].xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="jpg" ContentType="image/jpeg"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>${imageFiles.length ? '<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>' : ""}</Types>` },
      { name: "_rels/.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
      { name: "xl/workbook.xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Session" sheetId="1" r:id="rId1"/><sheet name="Recorded Steps" sheetId="2" r:id="rId2"/><sheet name="Screenshots" sheetId="3" r:id="rId3"/></sheets></workbook>` },
      { name: "xl/_rels/workbook.xml.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/></Relationships>` },
      { name: "xl/worksheets/sheet1.xml", data: worksheet([["Field", "Value"], ["Session", session.name || "Untitled journey"], ["Tester", session.tester || ""], ["Application", session.applicationTitle || ""], ["Application URL", session.applicationUrl || ""], ["Started", session.startedAt || ""], ["Status", session.status || ""], ["Execution summary", `${(session.steps || []).length} steps; ${screenshots.length} screenshots`], ["Notes", session.notes || ""]]) },
      { name: "xl/worksheets/sheet2.xml", data: worksheet([["Step", "Action", "Element", "Value", "URL", "Timestamp", "Preferred locator", "Screenshot references"], ...(session.steps || []).map((step) => [step.stepNumber, step.type, step.elementLabel || step.elementText || "", step.value || "", step.url || "", step.timestamp || "", step.preferredLocator || "", (step.screenshotIds || []).join(", ")])]) },
      { name: "xl/worksheets/sheet3.xml", data: worksheet([["Screenshot", "Step", "Captured at", "URL", "Embedded image"], ...screenshots.map((shot, index) => [`Screenshot ${index + 1}`, shot.stepNumber || "", shot.capturedAt || "", shot.url || "", imageFiles.includes(shot) ? "See image to the right" : "Image unavailable"])], imageFiles.length > 0) }
    ];
    if (imageFiles.length) {
      files.push({ name: "xl/worksheets/_rels/sheet3.xml.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdDrawing" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>` });
      files.push({ name: "xl/drawings/drawing1.xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">${drawingXml}</xdr:wsDr>` });
      files.push({ name: "xl/drawings/_rels/drawing1.xml.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${imageFiles.map((_, index) => `<Relationship Id="rId${index + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image${index + 1}.jpg"/>`).join("")}</Relationships>` });
      imageFiles.forEach((shot, index) => files.push({ name: `xl/media/image${index + 1}.jpg`, data: dataUrlBytes(shot.dataUrl) }));
    }
    return zip(files);
  }
  function testCasesXlsx(testCases, context = {}) {
    if (!Array.isArray(testCases)) throw new Error("Test cases must be an array to export.");
    const categories = [...new Set(testCases.map((testCase) => testCase.category || "Uncategorized"))];
    const caseRows = [
      ["ID", "Title", "Category", "Coverage Type", "Priority", "Test Steps", "Expected Result", "Source Journey Steps", "Review Required"],
      ...testCases.map((testCase) => [
        testCase.id || "",
        testCase.title || "",
        testCase.category || "",
        testCase.coverageType || "",
        testCase.priority || "",
        (Array.isArray(testCase.steps) ? testCase.steps : []).map((step, index) => `${index + 1}. ${step}`).join("\n"),
        testCase.expectedResult || "",
        (Array.isArray(testCase.sourceStepNumbers) ? testCase.sourceStepNumbers : []).join(", "),
        testCase.requiresReview ? "Yes" : "No"
      ])
    ];
    const summaryRows = [
      ["Field", "Value"],
      ["Report", "Test Master generated test cases"],
      ["Generated At", context.generatedAt || new Date().toISOString()],
      ["Source Session", context.sessionName || "Untitled journey"],
      ["Application", context.application || ""],
      ["Total Test Cases", testCases.length],
      ...categories.map((category) => ["Category: " + category, testCases.filter((item) => (item.category || "Uncategorized") === category).length])
    ];
    return zip([
      { name: "[Content_Types].xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>` },
      { name: "_rels/.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
      { name: "xl/workbook.xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Summary" sheetId="1" r:id="rId1"/><sheet name="Test Cases" sheetId="2" r:id="rId2"/></sheets></workbook>` },
      { name: "xl/_rels/workbook.xml.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>` },
      { name: "xl/worksheets/sheet1.xml", data: worksheet(summaryRows) },
      { name: "xl/worksheets/sheet2.xml", data: worksheet(caseRows) }
    ]);
  }
  function jpegDimensions(data) {
    for (let i = 2; i < data.length - 9;) {
      if (data[i] !== 0xff) { i++; continue; }
      const marker = data[i + 1];
      const length = (data[i + 2] << 8) | data[i + 3];
      if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker)) {
        return { height: (data[i + 5] << 8) | data[i + 6], width: (data[i + 7] << 8) | data[i + 8] };
      }
      if (!length) break;
      i += length + 2;
    }
    return { width: 1, height: 1 };
  }
  function pdf(session) {
    const steps = session.steps || [];
    const pages = steps.length ? steps : [{ stepNumber: 0, type: "No recorded steps", elementLabel: "No steps were recorded.", timestamp: "", url: "" }];
    const objects = [];
    const setObject = (id, value) => { objects[id] = typeof value === "string" ? bytes(value) : value; };
    const pageIds = pages.map((_, index) => 5 + index * 3);
    const kids = pageIds.map((id) => `${id} 0 R`).join(" ");
    setObject(1, "<< /Type /Catalog /Pages 2 0 R >>");
    setObject(2, `<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`);
    setObject(3, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
    setObject(4, "<< /Producer (Test Master) /Title (Test Master Execution Evidence) >>");
    for (let i = 0; i < pages.length; i++) {
      const step = pages[i];
      const pageId = pageIds[i];
      const contentId = pageId + 1;
      const shot = (session.screenshots || []).find((item) => (step.screenshotIds || []).includes(item.id));
      const lines = [
        ["Test Master | Execution Evidence", 18],
        [`Session: ${session.name || "Untitled journey"}`, 12],
        [`Tester: ${session.tester || "Not specified"}`, 10],
        [`Application: ${session.applicationTitle || session.applicationUrl || "Not recorded"}`, 10],
        ...(i === 0 ? [[`Execution summary: ${steps.length} steps, ${(session.screenshots || []).length} screenshots, status ${session.status || "not recorded"}`, 9]] : []),
        [`Step ${step.stepNumber}: ${step.type} - ${step.elementLabel || step.elementText || ""}`, 12],
        [`Timestamp: ${step.timestamp || ""}`, 9],
        [`URL: ${step.url || ""}`, 8],
        [`Value: ${step.value || ""}`, 9],
        [`Locator: ${step.preferredLocator || ""}`, 8]
      ];
      let commands = "BT\n";
      let y = 790;
      for (const [line, size] of lines) {
        if (line.endsWith(": ")) continue;
        commands += `/F1 ${size} Tf 1 0 0 1 42 ${y} Tm (${pdfString(line).slice(0, 145)}) Tj\n`;
        y -= size === 18 ? 31 : 23;
      }
      if (session.notes && i === 0) {
        commands += `/F1 9 Tf 1 0 0 1 42 ${y - 10} Tm (Notes: ${pdfString(session.notes).slice(0, 140)}) Tj\n`;
      }
      let resources = "<< /Font << /F1 3 0 R >>";
      if (shot && shot.dataUrl && shot.dataUrl.startsWith("data:image/jpeg")) {
        const image = dataUrlBytes(shot.dataUrl);
        const size = jpegDimensions(image);
        const scale = Math.min(515 / size.width, 290 / size.height);
        const width = Math.max(1, Math.round(size.width * scale));
        const height = Math.max(1, Math.round(size.height * scale));
        const imageId = pageId + 2;
        commands += `q ${width} 0 0 ${height} 42 100 cm /Im${i + 1} Do Q\n`;
        resources += ` /XObject << /Im${i + 1} ${imageId} 0 R >>`;
        setObject(imageId, concat([bytes(`<< /Type /XObject /Subtype /Image /Width ${size.width} /Height ${size.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${image.length} >>\nstream\n`), image, bytes("\nendstream")]));
      }
      resources += " >>";
      const commandBytes = bytes(commands + "ET");
      setObject(contentId, concat([bytes(`<< /Length ${commandBytes.length} >>\nstream\n`), commandBytes, bytes("\nendstream")]));
      setObject(pageId, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources ${resources} /Contents ${contentId} 0 R >>`);
    }
    const chunks = [bytes("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n")];
    const offsets = [0];
    let length = chunks[0].length;
    for (let id = 1; id < objects.length; id++) {
      if (!objects[id]) { setObject(id, "<< >>"); }
      offsets[id] = length;
      const objectBytes = concat([bytes(`${id} 0 obj\n`), objects[id], bytes("\nendobj\n")]);
      chunks.push(objectBytes);
      length += objectBytes.length;
    }
    const xrefOffset = length;
    let xref = `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
    for (let id = 1; id < objects.length; id++) xref += `${String(offsets[id]).padStart(10, "0")} 00000 n \n`;
    xref += `trailer\n<< /Size ${objects.length} /Root 1 0 R /Info 4 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
    chunks.push(bytes(xref));
    return concat(chunks);
  }
  function dataUrl(content, mime) {
    let binary = "";
    const chunkSize = 0x8000;
    for (let i = 0; i < content.length; i += chunkSize) binary += String.fromCharCode(...content.subarray(i, i + chunkSize));
    return `data:${mime};base64,${btoa(binary)}`;
  }
  function json(session) { return JSON.stringify(session, null, 2); }
  function csv(session) {
    const quote = (value) => `"${String(value == null ? "" : value).replace(/"/g, '""')}"`;
    return [["Step", "Action", "Element", "Value", "URL", "Timestamp", "Locator", "Screenshot IDs"], ...(session.steps || []).map((step) => [step.stepNumber, step.type, step.elementLabel, step.value, step.url, step.timestamp, step.preferredLocator, (step.screenshotIds || []).join(";")])].map((row) => row.map(quote).join(",")).join("\r\n");
  }
  function evidenceHtml(session) {
    const shots = new Map((session.screenshots || []).map((shot) => [shot.id, shot]));
    const rows = (session.steps || []).map((step) => {
      const images = (step.screenshotIds || []).map((id) => shots.get(id)).filter((shot) => shot && shot.dataUrl).map((shot) => `<figure><img src="${shot.dataUrl}" alt="Screenshot captured ${xml(shot.capturedAt)}"><figcaption>${xml(shot.capturedAt)}</figcaption></figure>`).join("");
      return `<article><h2>${step.stepNumber}. ${xml(step.type)} · ${xml(step.elementLabel || step.elementText || "Page action")}</h2><p>${xml(step.timestamp)} · ${xml(step.url)}</p><p>${xml(step.value || "")}</p>${images}</article>`;
    }).join("");
    return `<!doctype html><meta charset="utf-8"><title>Test Master Evidence</title><style>body{font:14px Arial,sans-serif;color:#25243a;max-width:900px;margin:40px auto;padding:0 24px}h1{color:#5947bb}article{border-top:1px solid #ddd;padding:16px 0;break-inside:avoid}p{color:#666;font-size:12px;overflow-wrap:anywhere}img{max-width:100%;max-height:420px;object-fit:contain}figcaption{font-size:11px;color:#777}.print{padding:9px 14px}</style><button class="print" onclick="window.print()">Print / Save as PDF</button><h1>Test Master · Execution Evidence</h1><p>Session: ${xml(session.name || "Untitled journey")} · Tester: ${xml(session.tester || "Not specified")}</p><p>Application: ${xml(session.applicationTitle || session.applicationUrl || "Not recorded")} · Started: ${xml(session.startedAt || "")}</p><p>${xml(session.notes || "")}</p>${rows || "<p>No steps were recorded.</p>"}`;
  }
  window.TestMasterExports = { zip, docx, xlsx, testCasesXlsx, pdf, json, csv, evidenceHtml, dataUrl };
})();
