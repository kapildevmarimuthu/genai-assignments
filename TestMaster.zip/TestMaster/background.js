const SESSION_KEY = "traceqa.session";
const SETTINGS_KEY = "traceqa.settings";
const CASES_KEY = "traceqa.cases";
const MAX_STEPS = 2000;
const MAX_SCREENSHOTS = 12;
let actionQueue = Promise.resolve();

chrome.runtime.onInstalled.addListener(async () => {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
  } catch (error) {
    console.error("Test Master could not configure its action button.", error);
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  try {
    await chrome.sidePanel.open({ tabId: tab.id });
  } catch (error) {
    console.error("Test Master could not open its side panel.", error);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string") return;
  handleMessage(message, sender)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.status !== "complete") return;
  const session = await getSession();
  if (!session || session.status !== "recording" || session.tabId !== tabId) return;
  try {
    const page = await pageDetails(tabId);
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await chrome.tabs.sendMessage(tabId, { type: "QA_CONTENT_START", sessionId: session.id });
    await appendAction({
      sessionId: session.id,
      type: "Navigation",
      elementLabel: page.title || new URL(page.url).hostname,
      elementText: "",
      attributes: {},
      preferredLocator: "page",
      alternateLocators: [],
      url: page.url
    }, page.url, tabId);
  } catch (error) {
    const latest = await getSession();
    if (!latest || latest.id !== session.id) return;
    latest.status = "paused";
    latest.interruption = "Recording paused because the browser could not grant access to this page. Click Test Master while this tab is active, then resume.";
    latest.lastError = error.message || "The page could not be accessed.";
    latest.updatedAt = new Date().toISOString();
    await chrome.storage.local.set({ [SESSION_KEY]: latest });
  }
});

async function handleMessage(message, sender) {
  switch (message.type) {
    case "QA_GET_STATE":
      return { session: await getSession(), settings: await getSettings(), cases: (await chrome.storage.local.get(CASES_KEY))[CASES_KEY] || [] };
    case "QA_START":
      return startRecording();
    case "QA_PAUSE":
    case "QA_RESUME":
    case "QA_STOP":
      return changeRecordingState(message.type);
    case "QA_RESET":
      await chrome.storage.local.remove(SESSION_KEY);
      return { session: null };
    case "QA_CAPTURE":
      return captureEvidence();
    case "QA_ACTION":
      return appendAction(message.action, sender.tab && sender.tab.url, sender.tab && sender.tab.id);
    case "QA_CONTENT_ERROR": {
      const session = await getSession();
      if (session && message.sessionId === session.id && sender.tab && sender.tab.id === session.tabId) {
        session.lastError = String(message.message || "An action could not be saved.").slice(0, 300);
        session.updatedAt = new Date().toISOString();
        await chrome.storage.local.set({ [SESSION_KEY]: session });
      }
      return {};
    }
    case "QA_SAVE_SESSION":
      await chrome.storage.local.set({ [SESSION_KEY]: message.session });
      return { session: message.session };
    case "QA_SAVE_SETTINGS":
      await chrome.storage.local.set({ [SETTINGS_KEY]: message.settings });
      return { settings: message.settings };
    case "QA_SAVE_CASES":
      await chrome.storage.local.set({ [CASES_KEY]: message.cases });
      return { cases: message.cases };
    case "QA_GET_DOM":
      return getDomSnapshot();
    case "QA_GROQ_REQUEST":
      return requestGroq(message.payload);
    case "QA_DOWNLOAD":
      return downloadFile(message.filename, message.dataUrl);
    default:
      throw new Error("Unsupported request.");
  }
}

async function getSession() {
  const data = await chrome.storage.local.get(SESSION_KEY);
  return data[SESSION_KEY] || null;
}

async function getSettings() {
  const data = await chrome.storage.local.get(SETTINGS_KEY);
  return data[SETTINGS_KEY] || {};
}

async function currentTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab || !tab.id) throw new Error("No active browser tab was found. Open the website you want to record.");
  if (tab.url && !/^https?:/.test(tab.url)) {
    throw new Error("The active tab is not a website page. Select an HTTP or HTTPS page before recording.");
  }
  const page = await pageDetails(tab.id);
  return { ...tab, ...page };
}

async function pageDetails(tabId) {
  let results;
  try {
    results = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => ({ url: location.href, title: document.title })
    });
  } catch (error) {
    throw new Error(`Test Master could not access the active page. Click the Test Master toolbar button while the website tab is active to grant temporary access, then try again. ${error.message}`);
  }
  const page = results && results[0] && results[0].result;
  if (!page || !/^https?:/.test(page.url || "")) {
    throw new Error("Recording is available on regular HTTP or HTTPS website pages. Select the website tab rather than a browser or extension page.");
  }
  return page;
}

async function startRecording() {
  const tab = await currentTab();
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
  const session = {
    id: crypto.randomUUID(),
    status: "recording",
    tabId: tab.id,
    startedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    applicationUrl: tab.url,
    applicationTitle: tab.title || new URL(tab.url).hostname,
    steps: [],
    screenshots: [],
    notes: ""
  };
  await chrome.storage.local.set({ [SESSION_KEY]: session });
  await chrome.tabs.sendMessage(tab.id, { type: "QA_CONTENT_START", sessionId: session.id });
  return { session };
}

async function changeRecordingState(type) {
  const session = await getSession();
  if (!session) throw new Error("There is no recording session to update.");
  const tab = type === "QA_STOP" ? null : await recordingTab(session);
  if (type !== "QA_STOP") {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    const command = type === "QA_PAUSE" ? "QA_CONTENT_PAUSE" : "QA_CONTENT_RESUME";
    await chrome.tabs.sendMessage(tab.id, { type: command });
  }
  session.status = type === "QA_STOP" ? "stopped" : (type === "QA_PAUSE" ? "paused" : "recording");
  if (type === "QA_RESUME") delete session.interruption;
  session.updatedAt = new Date().toISOString();
  await chrome.storage.local.set({ [SESSION_KEY]: session });
  return { session };
}

function appendAction(action, senderUrl, senderTabId) {
  const result = actionQueue.then(() => appendActionNow(action, senderUrl, senderTabId));
  actionQueue = result.catch(() => {});
  return result;
}

async function appendActionNow(action, senderUrl, senderTabId) {
  if (!action || typeof action.type !== "string") throw new Error("Invalid recorded action.");
  const session = await getSession();
  if (!session || session.status !== "recording") return { ignored: true };
  if ((action.sessionId && action.sessionId !== session.id) || (senderTabId && session.tabId !== senderTabId)) return { ignored: true };
  if (session.steps.length >= MAX_STEPS) throw new Error(`Session limit reached (${MAX_STEPS} steps).`);
  const step = {
    ...action,
    stepNumber: session.steps.length + 1,
    timestamp: new Date().toISOString(),
    url: action.url || senderUrl || session.applicationUrl,
    screenshotIds: []
  };
  delete session.lastError;
  session.steps.push(step);
  session.updatedAt = step.timestamp;
  await chrome.storage.local.set({ [SESSION_KEY]: session });
  return { step };
}

async function captureEvidence() {
  const session = await getSession();
  if (!session) throw new Error("Start or open a session before capturing evidence.");
  if ((session.screenshots || []).length >= MAX_SCREENSHOTS) throw new Error(`This session has reached its ${MAX_SCREENSHOTS}-screenshot limit. Export the session before capturing more.`);
  const tab = await recordingTab(session);
  const page = await pageDetails(tab.id);
  const captured = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 72 });
  const dataUrl = await compressScreenshot(captured);
  const currentBytes = await chrome.storage.local.getBytesInUse(null);
  if (currentBytes + dataUrl.length > 8 * 1024 * 1024) {
    throw new Error("Local storage is nearly full. Export and reset this session before capturing more evidence.");
  }
  const screenshot = {
    id: crypto.randomUUID(),
    capturedAt: new Date().toISOString(),
    url: page.url,
    stepNumber: session.steps.length,
    dataUrl
  };
  session.screenshots.push(screenshot);
  const currentStep = session.steps[session.steps.length - 1];
  if (currentStep) currentStep.screenshotIds = [...(currentStep.screenshotIds || []), screenshot.id];
  session.updatedAt = screenshot.capturedAt;
  await chrome.storage.local.set({ [SESSION_KEY]: session });
  return { session, screenshot };
}

async function compressScreenshot(dataUrl) {
  if (typeof OffscreenCanvas === "undefined" || typeof createImageBitmap !== "function") {
    throw new Error("This browser cannot process screenshots in the extension worker.");
  }
  const raw = atob(dataUrl.split(",")[1] || "");
  const source = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) source[i] = raw.charCodeAt(i);
  const blob = new Blob([source], { type: "image/jpeg" });
  const bitmap = await createImageBitmap(blob);
  try {
    const scale = Math.min(1, 1440 / Math.max(bitmap.width, bitmap.height));
    const canvas = new OffscreenCanvas(Math.max(1, Math.round(bitmap.width * scale)), Math.max(1, Math.round(bitmap.height * scale)));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Could not prepare the screenshot for local storage.");
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    const compressed = new Uint8Array(await (await canvas.convertToBlob({ type: "image/jpeg", quality: 0.62 })).arrayBuffer());
    let binary = "";
    const chunkSize = 0x8000;
    for (let i = 0; i < compressed.length; i += chunkSize) binary += String.fromCharCode(...compressed.subarray(i, i + chunkSize));
    return `data:image/jpeg;base64,${btoa(binary)}`;
  } finally {
    bitmap.close();
  }
}

async function requestGroq(payload) {
  const settings = await getSettings();
  const apiKey = settings.groqApiKey;
  if (!apiKey) throw new Error("Add your Groq API key in Settings before generating test cases.");
  if (!payload || !Array.isArray(payload.messages)) throw new Error("Invalid AI request.");
  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: payload.model || settings.model || "llama-3.3-70b-versatile",
      temperature: Number.isFinite(payload.temperature) ? payload.temperature : 0.2,
      max_tokens: 5000,
      response_format: { type: "json_object" },
      messages: payload.messages
    })
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error && body.error.message || `Groq request failed (${response.status}).`);
  return { result: body.choices && body.choices[0] && body.choices[0].message && body.choices[0].message.content };
}

async function recordingTab(session) {
  const tab = session.tabId ? await chrome.tabs.get(session.tabId).catch(() => null) : null;
  if (!tab) throw new Error("The recorded tab is no longer available. Start a new session.");
  if (!tab.active) throw new Error("Switch back to the recorded browser tab to control the session or capture evidence.");
  return tab;
}

async function getDomSnapshot() {
  const tab = await currentTab();
  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const clean = (text) => String(text || "").replace(/\s+/g, " ").trim().slice(0, 100);
      const visible = (el) => {
        const rect = el.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && getComputedStyle(el).visibility !== "hidden";
      };
      const controls = Array.from(document.querySelectorAll("input,textarea,select,button,a,[role=button],[role=link]"))
        .filter(visible).slice(0, 100).map((el) => ({
          tag: el.tagName.toLowerCase(),
          type: el.getAttribute("type") || "",
          label: clean(el.getAttribute("aria-label") || (el.labels && Array.from(el.labels).map((label) => label.innerText).join(" ")) || el.innerText || el.getAttribute("placeholder") || el.getAttribute("name")),
          role: el.getAttribute("role") || "",
          name: clean(el.getAttribute("name")),
          required: el.required === true
        })).filter((el) => el.label || el.tag);
      const headings = Array.from(document.querySelectorAll("h1,h2,h3")).filter(visible).slice(0, 20).map((el) => clean(el.innerText));
      return { title: document.title, url: location.href, headings, controls };
    }
  });
  return { snapshot: result && result.result || { title: tab.title, url: tab.url, controls: [], headings: [] } };
}

async function downloadFile(filename, dataUrl) {
  if (typeof filename !== "string" || typeof dataUrl !== "string" || !dataUrl.startsWith("data:")) {
    throw new Error("Invalid download request.");
  }
  const downloadId = await chrome.downloads.download({
    url: dataUrl,
    filename: `Test Master/${filename.replace(/[\\/:*?"<>|]/g, "_")}`,
    saveAs: true
  });
  return { downloadId };
}
